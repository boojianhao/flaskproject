class Users:
    def __init__(self, email, password, name, address, security_question_1, security_question_2, active=True):
        self.__email = email
        self.__password = password
        self.__name = name
        self.__address = address
        self.__security_question_1 = security_question_1
        self.__security_question_2 = security_question_2
        self.__active = active
        self.__points = 0

    def set_email(self, email):
        self.__email = email

    def set_password(self, password):
        self.__password = password

    def set_name(self, name):
        self.__name = name

    def set_address(self, address):
        self.__address = address

    def set_security_question_1(self, security_question_1):
        self.__security_question_1 = security_question_1

    def set_security_question_2(self, security_question_2):
        self.__security_question_2 = security_question_2

    def set_points(self, points):
        self.__points = points

    def get_email(self):
        return self.__email

    def get_password(self):
        return self.__password

    def get_name(self):
        return self.__name

    def get_address(self):
        return self.__address

    def get_security_question_1(self):
        return self.__security_question_1

    def get_security_question_2(self):
        return self.__security_question_2

    def get_points(self):
        return self.__points

    def is_active(self):
        return self.__active

    def is_admin(self):
        return False

    def is_driver(self):
        return False

    def deactivate(self):
        self.__active = False